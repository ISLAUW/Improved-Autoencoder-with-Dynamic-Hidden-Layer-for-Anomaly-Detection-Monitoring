## -------------------- Autoencoder with hidden layer based on ARIMA --------------------

import pandas as pd
import numpy as np
from numpy.random import seed

seed(1)
import tensorflow as tf

tf.random.set_seed(1)
# from tensorflow import set.random_seed
# set.random_seed(1)

import pickle
import json
import matplotlib.pyplot as plt
from scipy import stats

import seaborn as sns
from pylab import rcParams
from sklearn.model_selection import train_test_split
from keras.models import Model, load_model, Sequential
from keras.layers import Input, Dense
from keras.callbacks import ModelCheckpoint, TensorBoard
from keras import regularizers
from keras import optimizers
import os.path

from statsmodels.tsa.statespace.sarimax import SARIMAX
from itertools import product
from tqdm import tqdm_notebook

import statsmodels.api as sm
import itertools
import seaborn as sns

from sklearn.metrics import mean_squared_error
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import r2_score
import math
import xlrd
import statistics as st

import time

start = time.process_time()


def Normalize_Data(data):
    Max_data = np.max(data)
    Min_data = np.min(data)
    Normalized_data = (data - Min_data) / (Max_data - Min_data)
    return Normalized_data, Max_data, Min_data


def build_network_layers(input, input_dim, output_dim, widths, activation, name):
    """
    Construct one portion of the network (either encoder or decoder).
    Arguments:
        input - 2D tensorflow array, input to the network (shape is [?,input_dim])
            input_dim - Integer, number of state variables in the input to the first layer
            output_dim - Integer, number of state variables to output from the final layer
            widths - List of integers representing how many units are in each network layer
            activation - Tensorflow function to be used as the activation function at each layer
            name - String, prefix to be used in naming the tensorflow variables
    Returns:
        input - Tensorflow array, output of the network layers (shape is [?,output_dim])
        weights - List of tensorflow arrays containing the network weights
        biases - List of tensorflow arrays containing the network biases
    """
    weights = []
    biases = []
    last_width = input_dim

    for i, n_units in enumerate(widths):
        W = tf.compat.v1.get_variable(name + '_W' + str(i), shape=[last_width, n_units], dtype='float32',
                                      initializer=tf.keras.initializers.GlorotNormal())
        b = tf.compat.v1.get_variable(name + '_b' + str(i), shape=[n_units], dtype='float32',
                                      initializer=tf.constant_initializer(0.0))

        input = tf.cast(input, tf.float32)
        input = tf.matmul(input, W) + b

        if activation is not None:
            input = activation(input)
        last_width = n_units
        weights.append(W)
        biases.append(b)

    W = tf.compat.v1.get_variable(name + '_W' + str(len(widths)), shape=[last_width, output_dim],
                                  initializer=tf.keras.initializers.GlorotNormal())
    b = tf.compat.v1.get_variable(name + '_b' + str(len(widths)), shape=[output_dim],
                                  initializer=tf.constant_initializer(0.0))
    input = tf.matmul(input, W) + b
    weights.append(W)
    biases.append(b)
    return input, weights, biases


def linear_autoencoder(x, input_dim, latent_dim):
    # z,encoder_weights,encoder_biases = encoder(x, input_dim, latent_dim, [], None, 'encoder')
    # x_decode,decoder_weights,decoder_biases = decoder(z, input_dim, latent_dim, [], None, 'decoder')
    z, encoder_weights, encoder_biases = build_network_layers(x, input_dim, latent_dim, [], None, 'encoder')
    x_decode, decoder_weights, decoder_biases = build_network_layers(z, latent_dim, input_dim, [], None, 'decoder')
    return z, x_decode, encoder_weights, encoder_biases, decoder_weights, decoder_biases


def hidden_layer(z):
    z = z.numpy()
    # z_latent = z
    n_z, m_z = np.shape(z)
    z_fit = np.empty(shape=(n_z, m_z))
    p = np.empty(shape=(m_z, 1))
    q = np.empty(shape=(m_z, 1))

    for i_z in range(m_z):
        # print('z', z)
        data = z[:, i_z]
        # print('i_z = ', i_z)
        # print('data shape', np.shape(data))
        # print('data', data)
        # print('data type', type(data))

        z_T = z.T
        data_exog = np.delete(z_T, i_z, 0)
        data_exog = data_exog.T
        # print('data_exog shape', np.shape(data_exog))
        # print('data_exog', data_exog)
        # print('data_exog type', type(data_exog))

        data_results = sm.tsa.arma_order_select_ic(data, ic=['aic', 'bic'], trend='n', max_ar=4, max_ma=4)
        # print('AIC', data_results.aic_min_order)
        # print('BIC', data_results.bic_min_order)

        p[i_z - 1, :], q[i_z - 1, :] = data_results.bic_min_order
        # print('p = ', p)
        # print('q = ', q)
        # best_model = sm.tsa.SARIMAX(endog=data, exog=data_exog, order=(p, 0, q)).fit(dis=-1)
        best_model = sm.tsa.SARIMAX(endog=data, order=(p[i_z - 1, :], 0, q[i_z - 1, :])).fit(dis=-1)
        z_fit[:, i_z - 1] = best_model.fittedvalues
    # print(z_fit)
    return z_fit, p, q


def hidden_layer_test(z, p, q):
    z = z.numpy()
    n_z, m_z = np.shape(z)
    z_fit = np.zeros([n_z, m_z])
    for i_z in range(m_z):
        data = z[:, i_z]
        z_T = z.T
        data_exog = np.delete(z_T, i_z, 0)
        data_exog = data_exog.T
        # best_model = sm.tsa.SARIMAX(endog=data, exog=data_exog, order=(p, 0, q)).fit(dis=-1)
        best_model = sm.tsa.SARIMAX(endog=data, order=(p[i_z - 1, :], 0, q[i_z - 1, :])).fit(dis=-1)
        z_fit[:, i_z - 1] = best_model.fittedvalues
    return z_fit


def nonlinear_autoencoder(x, input_dim, latent_dim, widths, activation='relu'):
    """
    Construct a nonlinear autoencoder.
    Arguments:
    Returns:
        z - hidden layer
        x_decode -
        encoder_weights - List of tensorflow arrays containing the encoder weights
        encoder_biases - List of tensorflow arrays containing the encoder biases
        decoder_weights - List of tensorflow arrays containing the decoder weights
        decoder_biases - List of tensorflow arrays containing the decoder biases
    """
    if activation == 'relu':
        activation_function = tf.nn.relu
    elif activation == 'elu':
        activation_function = tf.nn.elu
    elif activation == 'sigmoid':
        activation_function = tf.sigmoid
    elif activation == 'leaky relu':
        activation_function = tf.nn.leaky_relu
    else:
        raise ValueError('invalid activation function')

    # z,encoder_weights,encoder_biases = encoder(x, input_dim, latent_dim, widths, activation_function, 'encoder')
    # x_decode,decoder_weights,decoder_biases = decoder(z, input_dim, latent_dim, widths[::-1], activation_function, 'decoder')
    z, encoder_weights, encoder_biases = build_network_layers(x, input_dim, latent_dim, widths, activation_function,
                                                              'encoder')
    z_fit, p, q = hidden_layer(z)
    # z_fit = np.float32(z_fit)
    x_decode, decoder_weights, decoder_biases = build_network_layers(z_fit, latent_dim, input_dim, widths[::-1],
                                                                     activation_function, 'decoder')
    return z_fit, x_decode, encoder_weights, encoder_biases, decoder_weights, decoder_biases, p, q


def nonlinear_autoencoder_test(x, input_dim, latent_dim, widths, p, q, activation='relu'):
    """
    Construct a nonlinear autoencoder.
    Arguments:
    Returns:
        z - hidden layer
        x_decode -
        encoder_weights - List of tensorflow arrays containing the encoder weights
        encoder_biases - List of tensorflow arrays containing the encoder biases
        decoder_weights - List of tensorflow arrays containing the decoder weights
        decoder_biases - List of tensorflow arrays containing the decoder biases
    """
    if activation == 'relu':
        activation_function = tf.nn.relu
    elif activation == 'elu':
        activation_function = tf.nn.elu
    elif activation == 'sigmoid':
        activation_function = tf.sigmoid
    elif activation == 'leaky relu':
        activation_function = tf.nn.leaky_relu

    else:
        raise ValueError('invalid activation function')
    z, encoder_weights, encoder_biases = build_network_layers(x, input_dim, latent_dim, widths, activation_function,
                                                              'encoder')
    z_fit = hidden_layer_test(z, p, q)
    z_fit = np.float32(z_fit)
    x_decode, decoder_weights, decoder_biases = build_network_layers(z_fit, latent_dim, input_dim, widths[::-1],
                                                                     activation_function, 'decoder')
    return z_fit, x_decode, encoder_weights, encoder_biases, decoder_weights, decoder_biases


# path1 = r'E:\Research\Non-Stationary Neural Networks\Python\ARIMA-AE TEP 0917\TEP_FaultFree.xlsx'
# path2 = r'E:\Research\Non-Stationary Neural Networks\Python\ARIMA-AE TEP 0917\TEP_Faulty.xlsx'
# x = pd.read_excel(path1, sheet_name='Sheet1', header=None)
# x_test = pd.read_excel(path1, sheet_name='Sheet3', header=None) # normal
# x_test = pd.read_excel(path2, sheet_name='Sheet1', header=None)  # faulty 1


import os
files = os.listdir('.')
for filename in files:
    portion = os.path.splitext(filename)
    if portion[1] == ".dat":
        newname = portion[0] + ".txt"
        os.rename(filename, newname)

x = np.loadtxt('d00.txt')
x = x.T
#x_test = np.loadtxt('d00_te.txt') #normal
x_test = np.loadtxt('d02_te.txt') #faulty-step
#x_test = np.loadtxt('d06_te.txt') #faulty

x1 = x[:, 0:22]
x2 = x[:, 41:52]
# print('x1 shape', np.shape(x1))
# print('x2 shape', np.shape(x2))
x1_test = x_test[:, 0:22]
x2_test = x_test[:, 41:52]
# print('x1_test shape', np.shape(x1_test))
# print('x2_test shape', np.shape(x2_test))
x = np.hstack((x1, x2))
x_test = np.hstack((x1_test, x2_test))
# print('x_train shape', np.shape(x))
# print('x_test shape', np.shape(x_test))

x = x[:, 0:9]
x_test = x_test[:, 0:9]

xtrain_num, xtrain_dim = np.shape(x)
xtest_num, xtest_dim = np.shape(x_test)

latent_dim = xtrain_dim
width_number = 15
widths = [width_number]

t = np.arange(1, len(x) + 1)
t_test = np.arange(1, len(x_test) + 1)
# print('t shape', np.shape(t))
# print('t_test shape', np.shape(t_test))
# print('x shape', np.shape(x))
# print('x_test shape', np.shape(x_test))


# plt.figure()
# plt.subplot(2, 1, 1)
# plt.plot(t, x[:, 21], 'b-', linewidth=2)
# plt.subplot(2, 1, 2)
# plt.plot(t_test, x_test[:, 21], 'b-', linewidth=2)
# plt.show()

# x=x[0:19,:]
# x_test=x[0:19,:]


Normalized_x, x_max, x_min = Normalize_Data(x)
Normalized_x_test, x_test_max, x_test_min = Normalize_Data(x_test)

n_xtrain, m_xtrain = np.shape(Normalized_x)
n_xtest, m_xtest = np.shape(Normalized_x_test)
from sklearn.model_selection import train_test_split
from sklearn.model_selection import KFold
from sklearn.model_selection import cross_val_score

import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import f1_score
from sklearn.model_selection import GridSearchCV, RandomizedSearchCV
from sklearn.experimental import enable_halving_search_cv
from sklearn.model_selection import HalvingGridSearchCV, HalvingRandomSearchCV
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestRegressor
from scipy import stats
from skopt import BayesSearchCV
from skopt.space import Real, Categorical

Normalized_x_para_train, Normalized_x_para_test, Normalized_x_2_para_train, Normalized_x_2_para_test = train_test_split(
    Normalized_x, Normalized_x, test_size=0.5)

###########################################
def optimal_parameters(Normalized_x_para_train, Normalized_x_para_test):
    MSE_normalx = np.zeros((latent_dim, width_number))
    RMSE_normalx = np.zeros((latent_dim, width_number))
    NDEI_normalx = np.zeros((latent_dim, width_number))
    MAE_normalx = np.zeros((latent_dim, width_number))

    train_num, train_dim = np.shape(Normalized_x_para_train)
    test_num, test_dim = np.shape(Normalized_x_para_test)

    for i in range(latent_dim):
        for j in range(width_number):
            current_latent_dim = i + 1
            current_width_number = j + 1

            z_para_train, Normalized_x_para_train_decode, encoder_weights_para_train, encoder_biases_para_train, decoder_weights_para_train, decoder_biases_para_train, p, q = nonlinear_autoencoder(
            Normalized_x_para_train, train_dim, current_latent_dim, [current_width_number], activation='elu')
            z_para_test, Normalized_x_para_test_decode, encoder_test_weights_para_test, encoder_test_biases_para_test, decoder_test_weights_para_test, decoder_test_biases_para_test = nonlinear_autoencoder_test(
            Normalized_x_para_test, train_dim, current_latent_dim, [current_width_number], p, q, activation='elu')

            MSE_normalx[i, j] = mean_squared_error(Normalized_x_para_test_decode, Normalized_x_para_test)
            # RMSE_normalx[i, j] = math.sqrt(mean_squared_error(Normalized_x_para_test_decode, Normalized_x_para_test))
            # NDEI_normalx[i, j] = RMSE_normalx[i, j] / st.stdev(Normalized_x_para_test.flatten())
            # MAE_normalx[i, j] = mean_absolute_error(Normalized_x_para_test_decode, Normalized_x_para_test)

            print('current latent_dim = ', current_latent_dim)
            print('current widths = ', current_width_number)

    latent_dim_optwh, widths_optwh = np.where(MSE_normalx == np.min(MSE_normalx))
    # latent_dim_optwh, widths_optwh = np.where(RMSE_normalx == np.min(RMSE_normalx))
    # latent_dim_optwh, widths_optwh = np.where(NDEI_normalx == np.min(NDEI_normalx))
    # latent_dim_optwh, widths_optwh = np.where(MAE_normalx == np.min(MAE_normalx))

    latent_dim_opt = latent_dim_optwh + 1
    widths_opt = widths_optwh + 1

    latent_dim_opt = int(latent_dim_opt)
    widths_opt = int(widths_opt)

    print('optimal latent_dim =', latent_dim_opt)
    print('optimal widths =', widths_opt)
    return latent_dim_opt, widths_opt

#latent_dim_opt, widths_opt = optimal_parameters(Normalized_x_para_train, Normalized_x_para_test)
#########################################

########
latent_dim_opt = 8
widths_opt = 5
#######


######### -------------------------
z_train, X_train_pred, xtrain_encoder_weights, xtrain_encoder_biases, xtrain_decoder_weights, xtrain_decoder_biases, p, q = nonlinear_autoencoder(
    Normalized_x, xtrain_dim, latent_dim_opt, [widths_opt], activation='elu')
z_test, X_test_pred, xtest_encoder_weights, xtest_encoder_biases, xtest_decoder_weights, xtest_decoder_biases = nonlinear_autoencoder_test(
    Normalized_x_test, xtrain_dim, latent_dim_opt, [widths_opt], p, q, activation='elu')

# ------------------------- Metrics -------------------------
from sklearn.metrics import mean_squared_error
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import r2_score
import statistics as st

print('optimal latent_dim = ', latent_dim_opt)
print('optimal widths = ', widths_opt)

MSE_train = mean_squared_error(X_train_pred, Normalized_x)
MSE_test = mean_squared_error(X_test_pred, Normalized_x_test)
print('MSE_train', MSE_train)
print('MSE_test', MSE_test)

RMSE_train = math.sqrt(mean_squared_error(X_train_pred, Normalized_x))
RMSE_test = math.sqrt(mean_squared_error(X_test_pred, Normalized_x_test))
print('RMSE_train', RMSE_train)
print('RMSE_test', RMSE_test)

NDEI_train = RMSE_train / st.stdev(Normalized_x.flatten())
NDEI_test = RMSE_test / st.stdev(Normalized_x_test.flatten())
print('NDEI_train', NDEI_train)
print('NDEI_test', NDEI_test)

MAE_train = mean_absolute_error(X_train_pred, Normalized_x)
MAE_test = mean_absolute_error(X_test_pred, Normalized_x_test)
print('MAE_train', MAE_train)
print('MAE_test', MAE_test)

R2_train = r2_score(X_train_pred, Normalized_x)
R2_test = r2_score(X_test_pred, Normalized_x_test)
print("R2_train = ", R2_train)
print("R2_test = ", R2_test)

end = time.process_time()
process_time = (end - start) * 4 * 3 * 4
print("time consuming: {:.2f}s".format(process_time))


# ------------------------- Manual Feature Extraction -------------------------
# Peak-peak (p-p)
def peak_peak(x):
    x_num, x_dim = np.shape(x)
    pp = np.zeros(shape=(x_num,1))
    for i_pp in range(x_num):
        xi = x[i_pp, :]
        pp[i_pp, :] = abs(max(xi)) + abs(min(xi))
    return pp

# Skewness
from scipy.stats import skew
def skewness(x):
    x_num, x_dim = np.shape(x)
    sk = np.zeros(shape=(x_num, 1))
    for i_sk in range(x_num):
        xi = x[i_sk, :]
        sk[i_sk] = skew(xi)
    return sk

pp_train = peak_peak(Normalized_x)
pp_test0 = peak_peak(Normalized_x_test)
pp_test = peak_peak(X_test_pred)

#tt0 = len(pp_train)
#tt1 = len(pp_test0)
#XX0 = np.linspace(1, tt0, tt0)
#XX1 = np.linspace(1, tt1, tt1)
#plt.plot(XX0, pp_train, color='black', label='normal')
#plt.plot(XX1, pp_test, color='blue', label='faulty')
#plt.ylabel('Output')
#plt.xlabel('Samples')
#plt.legend()
#plt.show()

sk_train = skewness(Normalized_x)
sk_test0 = skewness(Normalized_x_test)
sk_test = skewness(X_test_pred)

#tt0 = len(sk_train)
#tt1 = len(sk_test0)
#XX0 = np.linspace(1, tt0, tt0)
#XX1 = np.linspace(1, tt1, tt1)
#plt.plot(XX0, sk_train, color='black', label='normal')
#plt.plot(XX1, sk_test, color='blue', label='faulty')
#plt.ylabel('Output')
#plt.xlabel('Samples')
#plt.legend()
#plt.show()

########
# ------------------------- Anomaly Score -------------------------
def anomaly_score_1(x_normal, x_normal_pred, x_test, x_test_pred):
    xnormal_num, xnormal_dim = np.shape(x_normal)
    xtest_num, xtest_dim = np.shape(x_test)
    error_normal = np.zeros(shape=(xnormal_num, xnormal_dim))
    error = np.zeros(shape=(xtest_num, xtest_dim))
    threshold = np.zeros(shape=(xnormal_num))
    ascore = np.zeros(shape=(xtest_num))
    mu_i = np.mean(np.mean(x_normal))
    determine = np.zeros(shape=(xtest_num))
    alpha = 0.125
    anomaly_x = []
    anomaly_y = []

    for i in range(xnormal_num):
        error_normal[i, :] = (x_normal[i, :] - x_normal_pred[i, :]) ** 2
        # error_normal[i, :] = np.abs(x_normal[i, :] - x_normal_pred[i, :])
        threshold[i] = (error_normal[i, :] - mu_i).T @ np.cov(x_normal.T) @ (error_normal[i, :] - mu_i)

    for i in range(xtest_num):
        #print('x_test[i, :] shape: ', np.shape(x_test[i, :]))
        #print('x_test_pred[i, :] shape: ', np.shape(x_test_pred[i, :]))

        error[i, :] = np.abs(x_test[i, :] - x_test_pred[i, :])**2
        # error[i, :] = np.abs(x_test[i, :] - x_test_pred[i, :])
        #print('error[i, :] shape: ', np.shape(error[i, :]))
        #print('np.cov(x_normal.T) shape: ', np.shape(np.cov(x_normal.T)))
        #print('error[i, :] - mu_i shape: ', np.shape(error[i, :] - mu_i))
        ascore[i] = (error[i, :] - mu_i).T @ np.cov(x_normal.T) @ (error[i, :] - mu_i)
    ascore_upper = (1 + alpha) * np.mean(ascore)
    ascore_lower = (1 - alpha) * np.mean(ascore)
    for i in range(xtest_num):
        if (ascore[i] > ascore_upper) | (ascore[i] < ascore_lower):
            anomaly_x = np.append(anomaly_x, [i])
            anomaly_y = np.append(anomaly_y, [ascore[i]])
    return ascore, ascore_upper, ascore_lower, anomaly_x, anomaly_y

ascore_train, threshold_train_upper, threshold_train_lower, anomaly_x_train, anomaly_y_train = anomaly_score_1(Normalized_x, X_train_pred, Normalized_x, X_train_pred)
ascore_test, threshold_test_upper, threshold_test_lower, anomaly_x_test, anomaly_y_test = anomaly_score_1(Normalized_x, X_train_pred, Normalized_x_test, X_test_pred)

#tt0 = len(ascore_train)
#tt1 = len(ascore_test)
#XX0 = np.linspace(1, tt0, tt0)
#XX1 = np.linspace(1, tt1, tt1)
#plt.plot(XX1, ascore_test, color='blue', label='faulty')
#plt.scatter(anomaly_x_test, anomaly_y_test, alpha=0.6, c='red', marker='v', label='anomaly')
#plt.ylabel('Output')
#plt.xlabel('Samples')
#plt.title('Anomaly Score')
#plt.legend()
#plt.show()


def anomaly_score_2(x_normal, x_normal_pred, x_test, x_test_pred):
    xnormal_num, xnormal_dim = np.shape(x_normal)
    xtest_num, xtest_dim = np.shape(x_test)
    error_normal = np.zeros(shape=(xnormal_num, xnormal_dim))
    error = np.zeros(shape=(xtest_num, xtest_dim))
    threshold = np.zeros(shape=(xnormal_num))
    #std_normal = np.zeros(shape=(xnormal_num))
    ascore = np.zeros(shape=(xtest_num))
    mu_i = np.mean(np.mean(x_normal))
    determine = np.zeros(shape=(xtest_num))
    alpha = 0.125
    ascorei_std = np.zeros(shape=(xtest_num))
    anomaly_x = []
    anomaly_y = []

    for i in range(xnormal_num):
        error_normal[i, :] = (x_normal[i, :] - x_normal_pred[i, :]) ** 2
        # error_normal[i, :] = np.abs(x_normal[i, :] - x_normal_pred[i, :])
        threshold[i] = (error_normal[i, :] - mu_i).T @ np.cov(x_normal.T) @ (error_normal[i, :] - mu_i)

    for i in range(xtest_num):
        #print('x_test[i, :] shape: ', np.shape(x_test[i, :]))
        #print('x_test_pred[i, :] shape: ', np.shape(x_test_pred[i, :]))

        error[i, :] = np.abs(x_test[i, :] - x_test_pred[i, :])**2
        # error[i, :] = np.abs(x_test[i, :] - x_test_pred[i, :])
        #print('error[i, :] shape: ', np.shape(error[i, :]))
        #print('np.cov(x_normal.T) shape: ', np.shape(np.cov(x_normal.T)))
        #print('error[i, :] - mu_i shape: ', np.shape(error[i, :] - mu_i))
        ascore[i] = (error[i, :] - mu_i).T @ np.cov(x_normal.T) @ (error[i, :] - mu_i)

    std_normal = np.std(ascore)
    #print('std_normal: ', std_normal)

    interval = 20

    for i in range(xtest_num):
        if (i > interval) & (i < xtest_num - interval):
            ascorei_std[i] = np.std(ascore[i - interval: i + interval])
            if ascorei_std[i] > std_normal:
                anomaly_x = np.append(anomaly_x, [i])
                anomaly_y = np.append(anomaly_y, [ascore[i]])
    return ascore, anomaly_x, anomaly_y

ascore_train_2, anomaly_x_train_2, anomaly_y_train_2 = anomaly_score_2(Normalized_x, X_train_pred, Normalized_x, X_train_pred)
ascore_test_2, anomaly_x_test_2, anomaly_y_test_2 = anomaly_score_2(Normalized_x, X_train_pred, Normalized_x_test, X_test_pred)

tt0_2 = len(ascore_train_2)
tt1_2 = len(ascore_test_2)
XX0_2 = np.linspace(1, tt0_2, tt0_2)
XX1_2 = np.linspace(1, tt1_2, tt1_2)
threshold_2 = np.mean(np.mean(ascore_test_2))
#print('threshold_2: ', threshold_2)
plt.plot(XX1_2, ascore_test_2, color='blue', label='faulty')
#plt.scatter(anomaly_x_test_2, anomaly_y_test_2, alpha=0.6, c='red', marker='v', label='anomaly')
plt.plot(XX1_2, (threshold_2 * np.ones(shape=tt1_2)), color='green', label='threshold')
plt.ylabel('Output')
plt.xlabel('Samples')
plt.title('Anomaly Score')
plt.legend()
plt.show()



############################################################
variable = 2 # IDV(2)
# variable = 8 #IDV(6)

plt.figure()
plt.subplot(2, 1, 1)
plt.plot(X_train_pred[:, variable], color='b', label='predictive training data')
plt.plot(Normalized_x[:, variable], color='r', label='original training data')
plt.legend(loc='best')
plt.title('Training data')
plt.subplot(2, 1, 2)
plt.plot(X_test_pred[:, variable], color='b', label='predictive testing data')
plt.plot(Normalized_x_test[:, variable], color='r', label='original testing data')
plt.legend(loc='best')
plt.title('Testing data')
plt.show()

#############################################################
# ------------------------- PCA & Anomaly Score -------------------------
from sklearn.decomposition import PCA
def pc_determine(x):
    x_num, x_dim = np.shape(x)
    mse = np.zeros(shape=x_dim)
    x_train = x[0:int(x_num/4*3), :]
    x_test = x[int(x_num/4*3) + 1: x_num-1, :]
    for i in range(x_dim):
        pca_i = PCA(n_components=i)
        pca_i.fit(x_train)
        x_test_transformed = pca_i.transform(x_test)
        pcs_i = pca_i.components_
        x_test_pred = np.matmul(x_test_transformed, pcs_i) + x_train.mean()
        mse[i] = mean_squared_error(x_test_pred, x_test)
    pc_num = np.argmin(np.array(mse))
    print('The number of principal components:', pc_num)
    return pc_num
    
pc_num = pc_determine(Normalized_x)
pca = PCA(n_components=pc_num)
#pca = PCA(n_components='mle')
pca.fit(Normalized_x)

# Project the data onto the first principal components
transformed_normal = pca.transform(Normalized_x)
transformed_test = pca.transform(Normalized_x_test)
pcs = pca.components_
print('Principal components: ', pcs)

X_train_pred_pca = np.matmul(transformed_normal, pcs) + Normalized_x.mean()
X_test_pred_pca = np.matmul(transformed_test, pcs) + Normalized_x.mean()

#############################################################
def anomaly_score_pca(x_normal, x_normal_pred, x_test, x_test_pred):
    xnormal_num, xnormal_dim = np.shape(x_normal)
    xtest_num, xtest_dim = np.shape(x_test)
    error_normal = np.zeros(shape=(xnormal_num, xnormal_dim))
    error = np.zeros(shape=(xtest_num, xtest_dim))
    threshold = np.zeros(shape=(xnormal_num))
    ascore = np.zeros(shape=(xtest_num))
    mu_i = np.mean(np.mean(x_normal))
    ascorei_std = np.zeros(shape=(xtest_num))
    anomaly_x = []
    anomaly_y = []

    for i in range(xnormal_num):
        error_normal[i, :] = (x_normal[i, :] - x_normal_pred[i, :]) ** 2
        threshold[i] = (error_normal[i, :] - mu_i).T @ np.cov(x_normal.T) @ (error_normal[i, :] - mu_i)

    for i in range(xtest_num):
        error[i, :] = np.abs(x_test[i, :] - x_test_pred[i, :])**2
        # error[i, :] = np.abs(x_test[i, :] - x_test_pred[i, :])
        #print('error[i, :] shape: ', np.shape(error[i, :]))
        #print('np.cov(x_normal.T) shape: ', np.shape(np.cov(x_normal.T)))
        #print('error[i, :] - mu_i shape: ', np.shape(error[i, :] - mu_i))
        ascore[i] = (error[i, :] - mu_i).T @ np.cov(x_normal.T) @ (error[i, :] - mu_i)
    
    # anomaly based on std
    std_normal = np.std(ascore)
    interval = 20
    for i in range(xtest_num):
        if (i > interval) & (i < xtest_num - interval):
            ascorei_std[i] = np.std(ascore[i - interval: i + interval])
            if ascorei_std[i] > std_normal:
                anomaly_x = np.append(anomaly_x, [i])
                anomaly_y = np.append(anomaly_y, [ascore[i]])
    return ascore, anomaly_x, anomaly_y

ascore_train_pca, anomaly_x_train_pca, anomaly_y_train_pca = anomaly_score_pca(Normalized_x, X_train_pred_pca, Normalized_x, X_train_pred_pca)
ascore_test_pca, anomaly_x_test_pca, anomaly_y_test_pca = anomaly_score_pca(Normalized_x, X_train_pred_pca, Normalized_x_test, X_test_pred_pca)

#############################################################
threshold_pca = np.mean(np.mean(ascore_test_pca))

def faulty_determine(ascore_test):
    anomaly_x = []
    anomaly_y = []
    faulty_binary = np.zeros(shape=len(ascore_test))
    for i in range(len(ascore_test)):
        if ascore_test[i] > np.mean(np.mean(ascore_test)):
            anomaly_x = np.append(anomaly_x, [i])
            anomaly_y = np.append(anomaly_y, [ascore_test_pca[i]])
            faulty_binary[i] = 1
    return anomaly_x, anomaly_y, faulty_binary
faulty_ae_no, faulty_ae_value, faulty_ae_binary = faulty_determine(ascore_test_2)
faulty_pca_no, faulty_pca_value, faulty_pca_binary = faulty_determine(ascore_test_pca)
#############################################################

tt0_pca = len(ascore_train_pca)
tt1_pca = len(ascore_test_pca)
XX0_pca = np.linspace(1, tt0_pca, tt0_pca)
XX1_pca = np.linspace(1, tt1_pca, tt1_pca)
plt.plot(XX1_2, ascore_test_pca, color='blue', label='faulty')
plt.plot(XX1_pca, (threshold_pca * np.ones(shape=tt1_pca)), color='green', label='threshold')
plt.ylabel('Output')
plt.xlabel('Samples')
plt.title('Anomaly Score')
plt.legend()
plt.show()

#############################################################
from sklearn.metrics import accuracy_score, precision_score, recall_score
accuracy_score = accuracy_score(faulty_pca_binary, faulty_ae_binary)
precision_score = precision_score(faulty_pca_binary, faulty_ae_binary)
recall_score = recall_score(faulty_pca_binary, faulty_ae_binary)
F1_score = 2 * (precision_score * recall_score) / (precision_score + recall_score)
print('accuracy_score =', accuracy_score)
print('precision_score =', precision_score)
print('recall_score =', recall_score)
print('F1_score =', F1_score)

# ------------------------- Confusion Matrix -------------------------
#from pycm import *
from sklearn.metrics import confusion_matrix
#print('faulty pca:', faulty_pca_binary)
#print('faulty ae:', faulty_ae_binary)
cm = confusion_matrix(faulty_pca_binary, faulty_ae_binary)
print('cm: ', cm)
TP = cm[0, 0]
FN = cm[0, 1]
FP = cm[1, 0]
TN = cm[1, 1]
FDR = TP/(TP+FN)
FAR = FP/(TN+FP)
MAR = FN/(TP+FN)
print('FDR = ', FDR)
print('FAR = ', FAR)
print('MAR = ', MAR)