import tensorflow as tf
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from itertools import product
import warnings
warnings.filterwarnings('ignore')
# %matplotlib inline
import seaborn as sns

import math
import statistics as st
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import r2_score  # R square


import os
files = os.listdir('.')
for filename in files:
    portion = os.path.splitext(filename)
    if portion[1] == ".dat":
        newname = portion[0] + ".txt"
        os.rename(filename, newname)

x = np.loadtxt('d00.txt')
x = x.T
#x_test = np.loadtxt('d00_te.txt') #normal
x_test = np.loadtxt('d02_te.txt') #faulty-step
#x_test = np.loadtxt('d06_te.txt') #faulty

x1 = x[:, 0:22]
x2 = x[:, 41:52]
# print('x1 shape', np.shape(x1))
# print('x2 shape', np.shape(x2))
x1_test = x_test[:, 0:22]
x2_test = x_test[:, 41:52]
# print('x1_test shape', np.shape(x1_test))
# print('x2_test shape', np.shape(x2_test))
x = np.hstack((x1, x2))
x_test = np.hstack((x1_test, x2_test))
# print('x_train shape', np.shape(x))
# print('x_test shape', np.shape(x_test))

#x = x[:, 0:9]
#x_test = x_test[:, 0:9]

xtrain_num, xtrain_dim = np.shape(x)
xtest_num, xtest_dim = np.shape(x_test)

# ----------------- Normalize the inputs -----------------
def Normalize_Data(data):
    Max_data = np.max(data)
    Min_data = np.min(data)
    Normalized_data = (data - Min_data) / (Max_data - Min_data)
    return Normalized_data, Max_data, Min_data

Normalized_X_train, x_max, x_min = Normalize_Data(x)
Normalized_X_test, x_test_max, x_test_min = Normalize_Data(x_test)
n_xtrain, m_xtrain = np.shape(Normalized_X_train)
n_xtest, m_xtest = np.shape(Normalized_X_test)

# ----------------- Variational Autoencoder (VAE) -----------------
from keras.models import Model
from keras.layers import Dense, Input
import torch
import torch.nn as nn
from tqdm import tqdm
# from torchvision.utils import save_image, make_grid

# Model Hyperparameters
#dataset_path = '~/datasets'
cuda = True
DEVICE = torch.device("cuda" if cuda else "cpu")
batch_size = 100
x_dim = xtrain_dim
hidden_dim = x_dim-2
latent_dim = x_dim-5
lr = 1e-3
epochs = 30

# Step 1. Load (or download) Dataset

# Step 2. Define model: Variational AutoEncoder (VAE)
"""
    A simple implementation of Gaussian MLP Encoder and Decoder
"""
class Encoder(nn.Module):
    def __init__(self, input_dim, hidden_dim, latent_dim):
        super(Encoder, self).__init__()

        self.FC_input = nn.Linear(input_dim, hidden_dim)
        self.FC_input2 = nn.Linear(hidden_dim, hidden_dim)
        self.FC_mean = nn.Linear(hidden_dim, latent_dim)
        self.FC_var = nn.Linear(hidden_dim, latent_dim)

        self.LeakyReLU = nn.LeakyReLU(0.1)

        self.training = True

    def forward(self, x):
        x = torch.from_numpy(np.asarray(x)).float()
        h_ = self.LeakyReLU(self.FC_input(x))
        h_ = self.LeakyReLU(self.FC_input2(h_))
        mean = self.FC_mean(h_)
        log_var = self.FC_var(h_)  # encoder produces mean and log of variance
        #             (i.e., parateters of simple tractable normal distribution "q"

        return mean, log_var


class Decoder(nn.Module):
    def __init__(self, latent_dim, hidden_dim, output_dim):
        super(Decoder, self).__init__()
        self.FC_hidden = nn.Linear(latent_dim, hidden_dim)
        self.FC_hidden2 = nn.Linear(hidden_dim, hidden_dim)
        self.FC_output = nn.Linear(hidden_dim, output_dim)

        self.LeakyReLU = nn.LeakyReLU(0.2)

    def forward(self, x):
        h = self.LeakyReLU(self.FC_hidden(x))
        h = self.LeakyReLU(self.FC_hidden2(h))

        x_hat = torch.sigmoid(self.FC_output(h))
        return x_hat


class Model(nn.Module):
    def __init__(self, Encoder, Decoder):
        super(Model, self).__init__()
        self.Encoder = Encoder
        self.Decoder = Decoder

    def reparameterization(self, mean, var):
        epsilon = torch.randn_like(var)  # sampling epsilon
        z = mean + var * epsilon  # reparameterization trick
        return z

    def forward(self, x):
        x = torch.from_numpy(np.asarray(x)).float()
        mean, log_var = self.Encoder(x)
        z = self.reparameterization(mean, torch.exp(0.5 * log_var))  # takes exponential function (log var -> var)
        x_hat = self.Decoder(z)
        return x_hat, mean, log_var


encoder = Encoder(input_dim=x_dim, hidden_dim=hidden_dim, latent_dim=latent_dim)
decoder = Decoder(latent_dim=latent_dim, hidden_dim=hidden_dim, output_dim=x_dim)
#model = Model(Encoder=encoder, Decoder=decoder).to(DEVICE)
model = Model(Encoder=encoder, Decoder=decoder)

# Step 3. Define Loss function (reprod. loss) and optimizer
from torch.optim import Adam
BCE_loss = nn.BCELoss()
def loss_function(x, x_hat, mean, log_var):
    reproduction_loss = nn.functional.binary_cross_entropy(x_hat, x, reduction='sum')
    KLD = - 0.5 * torch.sum(1+ log_var - mean.pow(2) - log_var.exp())
    return reproduction_loss + KLD
optimizer = Adam(model.parameters(), lr=lr)

# Step 4. Train Variational AutoEncoder (VAE)
print("Start training VAE...")
model.train()
model.eval()

#X_train_pred, commitment_loss_train, codebook_loss_train, perplexity_train = model(Normalized_X_train)
#X_test_pred, commitment_loss_test, codebook_loss_test, perplexity_test = model(Normalized_X_test)

X_train_pred_tensor, commitment_loss_train, codebook_loss_train = model(Normalized_X_train)
X_test_pred_tensor, commitment_loss_test, codebook_loss_test = model(Normalized_X_test)
X_train_pred = X_train_pred_tensor.detach().cpu().numpy()
X_test_pred = X_test_pred_tensor.detach().cpu().numpy()

print('X_train_pred shape:', np.shape(X_train_pred))
#print('X_train_pred:', X_train_pred)
print('X_test_pred shape:', np.shape(X_test_pred))
#print('X_test_pred:', X_test_pred)


# ------------------------- Metrics -------------------------
MSE_train = mean_squared_error(X_train_pred, Normalized_X_train)
MSE_test = mean_squared_error(X_test_pred, Normalized_X_test)
print('MSE_train', MSE_train)
print('MSE_test', MSE_test)

RMSE_train = math.sqrt(mean_squared_error(X_train_pred, Normalized_X_train))
RMSE_test = math.sqrt(mean_squared_error(X_test_pred, Normalized_X_test))
print('RMSE_train', RMSE_train)
print('RMSE_test', RMSE_test)

NDEI_train = RMSE_train / st.stdev(Normalized_X_train.flatten())
NDEI_test = RMSE_test / st.stdev(Normalized_X_test.flatten())
print('NDEI_train', NDEI_train)
print('NDEI_test', NDEI_test)

MAE_train = mean_absolute_error(X_train_pred, Normalized_X_train)
MAE_test = mean_absolute_error(X_test_pred, Normalized_X_test)
print('MAE_train', MAE_train)
print('MAE_test', MAE_test)

#R2_train = r2_score(X_train_pred, Normalized_X_train)
#R2_test = r2_score(X_test_pred, Normalized_X_test)
#print("R2_train = ", R2_train)
#print("R2_test = ", R2_test)

############################################################
threshold_test = 0.3
scored_test = np.mean(np.abs(X_test_pred-Normalized_X_test)**2, axis=1) #Loss_mae
anomaly_test = np.zeros(shape=(len(scored_test)))
anomaly_x_test = []
anomaly_y_test = []
for i in range(len(scored_test)):
    if scored_test[i] > threshold_test:
        anomaly_test[i] = 1
        anomaly_x_test = np.append(anomaly_x_test, [i])
        anomaly_y_test = np.append(anomaly_y_test, [scored_test[i]])

threshold_train = 0.3
scored_train = np.mean(np.abs(X_train_pred-Normalized_X_train)**2, axis=1) #Loss_mae
anomaly_train = np.zeros(shape=(len(scored_train)))
anomaly_x_train = []
anomaly_y_train = []
for i in range(len(scored_train)):
    if scored_train[i] > threshold_train:
        anomaly_train[i] = 1
        anomaly_x_train = np.append(anomaly_x_train, [i])
        anomaly_y_train = np.append(anomaly_y_train, [scored_test[i]])

plt.figure()
t_train = len(anomaly_train)
t_test = len(anomaly_test)
tt_train = np.linspace(1, t_train, t_train)
tt_test = np.linspace(1, t_test, t_test)
plt.plot(tt_test, scored_test, color='blue', label='faulty')
#plt.plot(tt_train, scored_train, color='green', label='normal')
#plt.plot(tt_test, (threshold_test * np.ones(shape=t_test)), color='red', label='threshold')
plt.show()


# ------------------------- Anomaly Score -------------------------
def anomaly_score_2(x_normal, x_normal_pred, x_test, x_test_pred):
    xnormal_num, xnormal_dim = np.shape(x_normal)
    xtest_num, xtest_dim = np.shape(x_test)
    error_normal = np.zeros(shape=(xnormal_num, xnormal_dim))
    error = np.zeros(shape=(xtest_num, xtest_dim))
    threshold = np.zeros(shape=(xnormal_num))
    #std_normal = np.zeros(shape=(xnormal_num))
    ascore = np.zeros(shape=(xtest_num))
    mu_i = np.mean(np.mean(x_normal))
    determine = np.zeros(shape=(xtest_num))
    alpha = 0.125
    ascorei_std = np.zeros(shape=(xtest_num))
    anomaly_x = []
    anomaly_y = []

    for i in range(xnormal_num):
        error_normal[i, :] = (x_normal[i, :] - x_normal_pred[i, :]) ** 2
        # error_normal[i, :] = np.abs(x_normal[i, :] - x_normal_pred[i, :])
        threshold[i] = (error_normal[i, :] - mu_i).T @ np.cov(x_normal.T) @ (error_normal[i, :] - mu_i)

    for i in range(xtest_num):
        #print('x_test[i, :] shape: ', np.shape(x_test[i, :]))
        #print('x_test_pred[i, :] shape: ', np.shape(x_test_pred[i, :]))

        error[i, :] = np.abs(x_test[i, :] - x_test_pred[i, :])**2
        # error[i, :] = np.abs(x_test[i, :] - x_test_pred[i, :])
        #print('error[i, :] shape: ', np.shape(error[i, :]))
        #print('np.cov(x_normal.T) shape: ', np.shape(np.cov(x_normal.T)))
        #print('error[i, :] - mu_i shape: ', np.shape(error[i, :] - mu_i))
        ascore[i] = (error[i, :] - mu_i).T @ np.cov(x_normal.T) @ (error[i, :] - mu_i)

    std_normal = np.std(ascore)
    #print('std_normal: ', std_normal)

    interval = 20

    for i in range(xtest_num):
        if (i > interval) & (i < xtest_num - interval):
            ascorei_std[i] = np.std(ascore[i - interval: i + interval])
            if ascorei_std[i] > std_normal:
                anomaly_x = np.append(anomaly_x, [i])
                anomaly_y = np.append(anomaly_y, [ascore[i]])
    return ascore, anomaly_x, anomaly_y

ascore_train_2, anomaly_x_train_2, anomaly_y_train_2 = anomaly_score_2(Normalized_X_train, X_train_pred, Normalized_X_train, X_train_pred)
ascore_test_2, anomaly_x_test_2, anomaly_y_test_2 = anomaly_score_2(Normalized_X_train, X_train_pred, Normalized_X_test, X_test_pred)

tt0_2 = len(ascore_train_2)
tt1_2 = len(ascore_test_2)
XX0_2 = np.linspace(1, tt0_2, tt0_2)
XX1_2 = np.linspace(1, tt1_2, tt1_2)
threshold_2 = np.mean(np.mean(ascore_test_2))
#print('threshold_2: ', threshold_2)
plt.plot(XX1_2, ascore_test_2, color='blue', label='faulty')
#plt.scatter(anomaly_x_test_2, anomaly_y_test_2, alpha=0.6, c='red', marker='v', label='anomaly')
plt.plot(XX1_2, (threshold_2 * np.ones(shape=tt1_2)), color='green', label='threshold')
plt.ylabel('Output')
plt.xlabel('Samples')
plt.title('Anomaly Score')
plt.legend()
plt.show()

# ------------------------- DKPCA & Anomaly Score -------------------------
#from sklearn.decomposition import PCA
import matlab
import matlab.engine
eng = matlab.engine.start_matlab()
sig = 2000
K_train = eng.kernel_function(Normalized_X_train, sig)
print("K_train:", K_train)
s = 5
#[P, R, Alpha, VV, P_vd, lambda_vd, T2_lim_vd, Q_lim_vd] = eng.dipca(X0,a,s)

def pc_determine(x):
    x_num, x_dim = np.shape(x)
    mse = np.zeros(shape=x_dim)
    #x_train = x[0:int(x_num / 4 * 3), :]
    #x_test = x[int(x_num / 4 * 3) + 1: x_num - 1, :]
    for i in range(x_dim):
        results_i = eng.dipca(x, i, s)
        print (results_i)
        x_pred = np.matmul(x, results_i[1])
        #x_test_pred = np.matmul(x_test_transformed, pcs_i) + x_train.mean()
        mse[i] = mean_squared_error(x_pred, x)
    
    pc_num = np.argmin(np.array(mse))
    print('The number of principal components:', pc_num)
    return pc_num

#eng.quit()

pc_num = pc_determine(Normalized_X_train)
results_train = eng.dipca(K_train,pc_num,s)
K_test = eng.kernel_function(Normalized_X_test, sig)
results_test = eng.dipca(K_test, pc_num, s)

X_train_pred_pca = np.matmul(K_train, results_train[1])
X_test_pred_pca = np.matmul(K_test, results_test[1])

#############################################################
def anomaly_score_pca(x_normal, x_normal_pred, x_test, x_test_pred):
    xnormal_num, xnormal_dim = np.shape(x_normal)
    xtest_num, xtest_dim = np.shape(x_test)
    error_normal = np.zeros(shape=(xnormal_num, xnormal_dim))
    error = np.zeros(shape=(xtest_num, xtest_dim))
    threshold = np.zeros(shape=(xnormal_num))
    ascore = np.zeros(shape=(xtest_num))
    mu_i = np.mean(np.mean(x_normal))
    ascorei_std = np.zeros(shape=(xtest_num))
    anomaly_x = []
    anomaly_y = []

    for i in range(xnormal_num):
        error_normal[i, :] = (x_normal[i, :] - x_normal_pred[i, :]) ** 2
        threshold[i] = (error_normal[i, :] - mu_i).T @ np.cov(x_normal.T) @ (error_normal[i, :] - mu_i)

    for i in range(xtest_num):
        error[i, :] = np.abs(x_test[i, :] - x_test_pred[i, :]) ** 2
        # error[i, :] = np.abs(x_test[i, :] - x_test_pred[i, :])
        # print('error[i, :] shape: ', np.shape(error[i, :]))
        # print('np.cov(x_normal.T) shape: ', np.shape(np.cov(x_normal.T)))
        # print('error[i, :] - mu_i shape: ', np.shape(error[i, :] - mu_i))
        ascore[i] = (error[i, :] - mu_i).T @ np.cov(x_normal.T) @ (error[i, :] - mu_i)

    # anomaly based on std
    std_normal = np.std(ascore)
    interval = 20
    for i in range(xtest_num):
        if (i > interval) & (i < xtest_num - interval):
            ascorei_std[i] = np.std(ascore[i - interval: i + interval])
            if ascorei_std[i] > std_normal:
                anomaly_x = np.append(anomaly_x, [i])
                anomaly_y = np.append(anomaly_y, [ascore[i]])
    return ascore, anomaly_x, anomaly_y


ascore_train_pca, anomaly_x_train_pca, anomaly_y_train_pca = anomaly_score_pca(Normalized_X_train, X_train_pred_pca,
                                                                               Normalized_X_train, X_train_pred_pca)
ascore_test_pca, anomaly_x_test_pca, anomaly_y_test_pca = anomaly_score_pca(Normalized_X_train, X_train_pred_pca,
                                                                            Normalized_X_test, X_test_pred_pca)

#############################################################
threshold_pca = np.mean(np.mean(ascore_test_pca))


def faulty_determine(ascore_test):
    anomaly_x = []
    anomaly_y = []
    faulty_binary = np.zeros(shape=len(ascore_test))
    for i in range(len(ascore_test)):
        if ascore_test[i] > np.mean(np.mean(ascore_test)):
            anomaly_x = np.append(anomaly_x, [i])
            anomaly_y = np.append(anomaly_y, [ascore_test_pca[i]])
            faulty_binary[i] = 1
    return anomaly_x, anomaly_y, faulty_binary


faulty_ae_no, faulty_ae_value, faulty_ae_binary = faulty_determine(ascore_test_2)
faulty_pca_no, faulty_pca_value, faulty_pca_binary = faulty_determine(ascore_test_pca)




#############################################################
#tt0_pca = len(ascore_train_pca)
#tt1_pca = len(ascore_test_pca)
#XX0_pca = np.linspace(1, tt0_pca, tt0_pca)
#XX1_pca = np.linspace(1, tt1_pca, tt1_pca)
#plt.plot(XX1_2, ascore_test_pca, color='blue', label='faulty')
#plt.plot(XX1_pca, (threshold_pca * np.ones(shape=tt1_pca)), color='green', label='threshold')
#plt.ylabel('Output')
#plt.xlabel('Samples')
#plt.title('Anomaly Score')
#plt.legend()
#plt.show()
#############################################################

from sklearn.metrics import accuracy_score, precision_score, recall_score
accuracy_score = accuracy_score(faulty_pca_binary, faulty_ae_binary)
precision_score = precision_score(faulty_pca_binary, faulty_ae_binary)
recall_score = recall_score(faulty_pca_binary, faulty_ae_binary)
F1_score = 2 * (precision_score * recall_score) / (precision_score + recall_score)
print('accuracy_score =', accuracy_score)
print('precision_score =', precision_score)
print('recall_score =', recall_score)
print('F1_score =', F1_score)

# ------------------------- Confusion Matrix -------------------------
# from pycm import *
from sklearn.metrics import confusion_matrix

# print('faulty pca:', faulty_pca_binary)
# print('faulty ae:', faulty_ae_binary)
cm = confusion_matrix(faulty_pca_binary, faulty_ae_binary)
print('cm: ', cm)
TP = cm[0, 0]
FN = cm[0, 1]
FP = cm[1, 0]
TN = cm[1, 1]
FDR = TP / (TP + FN)
FAR = FP / (TN + FP)
MAR = FN / (TP + FN)
print('FDR = ', FDR)
print('FAR = ', FAR)
print('MAR = ', MAR)
