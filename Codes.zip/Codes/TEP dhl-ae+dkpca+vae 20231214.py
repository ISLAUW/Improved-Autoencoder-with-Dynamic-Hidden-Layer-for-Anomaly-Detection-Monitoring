## -------------------- Autoencoder with hidden layer based on ARIMA --------------------

import pandas as pd
import numpy as np
from numpy.random import seed

import pyod

seed(1)
import tensorflow as tf

tf.random.set_seed(1)
# from tensorflow import set.random_seed
# set.random_seed(1)

import pickle
import json
import matplotlib.pyplot as plt
from scipy import stats

import seaborn as sns
from pylab import rcParams
from sklearn.model_selection import train_test_split
from keras.models import Model, load_model, Sequential
from keras.layers import Input, Dense
from keras.callbacks import ModelCheckpoint, TensorBoard
from keras import regularizers
from keras import optimizers
import os.path

from statsmodels.tsa.statespace.sarimax import SARIMAX
from itertools import product
from tqdm import tqdm_notebook

import statsmodels.api as sm
import itertools
import seaborn as sns

from sklearn.metrics import mean_squared_error
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import r2_score
import math
import xlrd
import statistics as st

import time

start = time.process_time()


def Normalize_Data(data):
    Max_data = np.max(data)
    Min_data = np.min(data)
    Normalized_data = (data - Min_data) / (Max_data - Min_data)
    return Normalized_data, Max_data, Min_data


def build_network_layers(input, input_dim, output_dim, widths, activation, name):
    """
    Construct one portion of the network (either encoder or decoder).
    Arguments:
        input - 2D tensorflow array, input to the network (shape is [?,input_dim])
            input_dim - Integer, number of state variables in the input to the first layer
            output_dim - Integer, number of state variables to output from the final layer
            widths - List of integers representing how many units are in each network layer
            activation - Tensorflow function to be used as the activation function at each layer
            name - String, prefix to be used in naming the tensorflow variables
    Returns:
        input - Tensorflow array, output of the network layers (shape is [?,output_dim])
        weights - List of tensorflow arrays containing the network weights
        biases - List of tensorflow arrays containing the network biases
    """
    weights = []
    biases = []
    last_width = input_dim

    for i, n_units in enumerate(widths):
        W = tf.compat.v1.get_variable(name + '_W' + str(i), shape=[last_width, n_units], dtype='float32',
                                      initializer=tf.keras.initializers.GlorotNormal())
        b = tf.compat.v1.get_variable(name + '_b' + str(i), shape=[n_units], dtype='float32',
                                      initializer=tf.constant_initializer(0.0))

        input = tf.cast(input, tf.float32)
        input = tf.matmul(input, W) + b

        if activation is not None:
            input = activation(input)
        last_width = n_units
        weights.append(W)
        biases.append(b)

    W = tf.compat.v1.get_variable(name + '_W' + str(len(widths)), shape=[last_width, output_dim],
                                  initializer=tf.keras.initializers.GlorotNormal())
    b = tf.compat.v1.get_variable(name + '_b' + str(len(widths)), shape=[output_dim],
                                  initializer=tf.constant_initializer(0.0))
    input = tf.matmul(input, W) + b
    weights.append(W)
    biases.append(b)
    return input, weights, biases


def linear_autoencoder(x, input_dim, latent_dim):
    # z,encoder_weights,encoder_biases = encoder(x, input_dim, latent_dim, [], None, 'encoder')
    # x_decode,decoder_weights,decoder_biases = decoder(z, input_dim, latent_dim, [], None, 'decoder')
    z, encoder_weights, encoder_biases = build_network_layers(x, input_dim, latent_dim, [], None, 'encoder')
    x_decode, decoder_weights, decoder_biases = build_network_layers(z, latent_dim, input_dim, [], None, 'decoder')
    return z, x_decode, encoder_weights, encoder_biases, decoder_weights, decoder_biases


def hidden_layer(z):
    z = z.numpy()
    # z_latent = z
    n_z, m_z = np.shape(z)
    z_fit = np.empty(shape=(n_z, m_z))
    p = np.empty(shape=(m_z, 1))
    q = np.empty(shape=(m_z, 1))

    for i_z in range(m_z):
        # print('z', z)
        data = z[:, i_z]
        # print('i_z = ', i_z)
        # print('data shape', np.shape(data))
        # print('data', data)
        # print('data type', type(data))

        z_T = z.T
        data_exog = np.delete(z_T, i_z, 0)
        data_exog = data_exog.T
        # print('data_exog shape', np.shape(data_exog))
        # print('data_exog', data_exog)
        # print('data_exog type', type(data_exog))

        data_results = sm.tsa.arma_order_select_ic(data, ic=['aic', 'bic'], trend='n', max_ar=5, max_ma=5)
        # print('AIC', data_results.aic_min_order)
        # print('BIC', data_results.bic_min_order)

        p[i_z - 1, :], q[i_z - 1, :] = data_results.bic_min_order
        # print('p = ', p)
        # print('q = ', q)
        #best_model = sm.tsa.SARIMAX(endog=data, exog=data_exog, order=(p, 0, q)).fit(dis=-1)
        best_model = sm.tsa.SARIMAX(endog=data, order=(p[i_z - 1, :], 0, q[i_z - 1, :])).fit(dis=-1)
        z_fit[:, i_z - 1] = best_model.fittedvalues
    # print(z_fit)
    return z_fit, p, q


def hidden_layer_test(z, p, q):
    z = z.numpy()
    n_z, m_z = np.shape(z)
    z_fit = np.zeros([n_z, m_z])
    for i_z in range(m_z):
        data = z[:, i_z]
        z_T = z.T
        data_exog = np.delete(z_T, i_z, 0)
        data_exog = data_exog.T
        #best_model = sm.tsa.SARIMAX(endog=data, exog=data_exog, order=(p, 0, q)).fit(dis=-1)
        best_model = sm.tsa.SARIMAX(endog=data, order=(p[i_z - 1, :], 0, q[i_z - 1, :])).fit(dis=-1)
        z_fit[:, i_z - 1] = best_model.fittedvalues
    return z_fit


def nonlinear_autoencoder(x, input_dim, latent_dim, widths, activation='relu'):
    """
    Construct a nonlinear autoencoder.
    Arguments:
    Returns:
        z - hidden layer
        x_decode -
        encoder_weights - List of tensorflow arrays containing the encoder weights
        encoder_biases - List of tensorflow arrays containing the encoder biases
        decoder_weights - List of tensorflow arrays containing the decoder weights
        decoder_biases - List of tensorflow arrays containing the decoder biases
    """
    if activation == 'relu':
        activation_function = tf.nn.relu
    elif activation == 'elu':
        activation_function = tf.nn.elu
    elif activation == 'sigmoid':
        activation_function = tf.sigmoid
    elif activation == 'leaky relu':
        activation_function = tf.nn.leaky_relu
    elif activation == 'tanh':
        activation_function = tf.nn.tanh
    elif activation == 'selu':
        activation_function = tf.nn.selu
    elif activation == 'softplus':
        activation_function = tf.nn.softplus
    elif activation == 'softmax':
        activation_function = tf.nn.softmax

    else:
        raise ValueError('invalid activation function')

    # z,encoder_weights,encoder_biases = encoder(x, input_dim, latent_dim, widths, activation_function, 'encoder')
    # x_decode,decoder_weights,decoder_biases = decoder(z, input_dim, latent_dim, widths[::-1], activation_function, 'decoder')
    z, encoder_weights, encoder_biases = build_network_layers(x, input_dim, latent_dim, widths, activation_function,
                                                              'encoder')
    z_fit, p, q = hidden_layer(z)
    # z_fit = np.float32(z_fit)
    x_decode, decoder_weights, decoder_biases = build_network_layers(z_fit, latent_dim, input_dim, widths[::-1],
                                                                     activation_function, 'decoder')
    return z_fit, x_decode.numpy(), encoder_weights, encoder_biases, decoder_weights, decoder_biases, p, q


def nonlinear_autoencoder_test(x, input_dim, latent_dim, widths, p, q, activation='relu'):
    """
    Construct a nonlinear autoencoder.
    Arguments:
    Returns:
        z - hidden layer
        x_decode -
        encoder_weights - List of tensorflow arrays containing the encoder weights
        encoder_biases - List of tensorflow arrays containing the encoder biases
        decoder_weights - List of tensorflow arrays containing the decoder weights
        decoder_biases - List of tensorflow arrays containing the decoder biases
    """
    if activation == 'relu':
        activation_function = tf.nn.relu
    elif activation == 'elu':
        activation_function = tf.nn.elu
    elif activation == 'sigmoid':
        activation_function = tf.sigmoid
    elif activation == 'leaky relu':
        activation_function = tf.nn.leaky_relu
    elif activation == 'tanh':
        activation_function = tf.tanh
    elif activation == 'selu':
        activation_function = tf.nn.selu
    elif activation == 'softplus':
        activation_function = tf.nn.softplus
    elif activation == 'softmax':
        activation_function = tf.nn.softmax

    else:
        raise ValueError('invalid activation function')
    z, encoder_weights, encoder_biases = build_network_layers(x, input_dim, latent_dim, widths, activation_function,
                                                              'encoder')
    z_fit = hidden_layer_test(z, p, q)
    z_fit = np.float32(z_fit)
    x_decode, decoder_weights, decoder_biases = build_network_layers(z_fit, latent_dim, input_dim, widths[::-1],
                                                                     activation_function, 'decoder')
    return z_fit, x_decode.numpy(), encoder_weights, encoder_biases, decoder_weights, decoder_biases


# path1 = r'E:\Research\Non-Stationary Neural Networks\Python\ARIMA-AE TEP 0917\TEP_FaultFree.xlsx'
# path2 = r'E:\Research\Non-Stationary Neural Networks\Python\ARIMA-AE TEP 0917\TEP_Faulty.xlsx'
# x = pd.read_excel(path1, sheet_name='Sheet1', header=None)
# x_test = pd.read_excel(path1, sheet_name='Sheet3', header=None) # normal
# x_test = pd.read_excel(path2, sheet_name='Sheet1', header=None)  # faulty 1


import os

files = os.listdir('.')
for filename in files:
    portion = os.path.splitext(filename)
    if portion[1] == ".dat":
        newname = portion[0] + ".txt"
        os.rename(filename, newname)

x = np.loadtxt('d00.txt')
x = x.T
# x_test = np.loadtxt('d00_te.txt') #normal
x_test = np.loadtxt('d02_te.txt')  # faulty-step
#x_test = np.loadtxt('d10_te.txt') #faulty

#x1 = x[:, 0:22]
#x2 = x[:, 41:52]
# print('x1 shape', np.shape(x1))
# print('x2 shape', np.shape(x2))
#x1_test = x_test[:, 0:22]
#x2_test = x_test[:, 41:52]
# print('x1_test shape', np.shape(x1_test))
# print('x2_test shape', np.shape(x2_test))
#x = np.hstack((x1, x2))
#x_test = np.hstack((x1_test, x2_test))
#print('x_train shape', np.shape(x))
#print('x_test shape', np.shape(x_test))

#x = x[:, 0:9]
#x_test = x_test[:, 0:9]

xtrain_num, xtrain_dim = np.shape(x)
xtest_num, xtest_dim = np.shape(x_test)

latent_dim = xtrain_dim
width_number = 15
widths = [width_number]

t = np.arange(1, len(x) + 1)
t_test = np.arange(1, len(x_test) + 1)
# print('t shape', np.shape(t))
# print('t_test shape', np.shape(t_test))
# print('x shape', np.shape(x))
# print('x_test shape', np.shape(x_test))


#plt.figure()
#plt.subplot(2, 1, 1)
#plt.plot(t, x[:, 2], 'b-', linewidth=2)
#plt.subplot(2, 1, 2)
#plt.plot(t_test, x_test[:, 2], 'b-', linewidth=2)
#plt.show()

# x=x[0:19,:]
# x_test=x[0:19,:]


Normalized_x, x_max, x_min = Normalize_Data(x)
Normalized_x_test, x_test_max, x_test_min = Normalize_Data(x_test)

n_xtrain, m_xtrain = np.shape(Normalized_x)
n_xtest, m_xtest = np.shape(Normalized_x_test)
from sklearn.model_selection import train_test_split
from sklearn.model_selection import KFold
from sklearn.model_selection import cross_val_score

import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import f1_score
from sklearn.model_selection import GridSearchCV, RandomizedSearchCV
from sklearn.experimental import enable_halving_search_cv
from sklearn.model_selection import HalvingGridSearchCV, HalvingRandomSearchCV
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestRegressor
from scipy import stats
from skopt import BayesSearchCV
from skopt.space import Real, Categorical

Normalized_x_para_train, Normalized_x_para_test, Normalized_x_2_para_train, Normalized_x_2_para_test = train_test_split(
    Normalized_x, Normalized_x, test_size=0.6)


###########################################
def optimal_parameters(Normalized_x_para_train, Normalized_x_para_test):
    MSE_normalx = np.zeros((latent_dim, width_number))
    RMSE_normalx = np.zeros((latent_dim, width_number))
    NDEI_normalx = np.zeros((latent_dim, width_number))
    MAE_normalx = np.zeros((latent_dim, width_number))

    train_num, train_dim = np.shape(Normalized_x_para_train)
    test_num, test_dim = np.shape(Normalized_x_para_test)

    for i in range(latent_dim):
        for j in range(width_number):
            current_latent_dim = i + 1
            current_width_number = j + 1

            z_para_train, Normalized_x_para_train_decode, encoder_weights_para_train, encoder_biases_para_train, decoder_weights_para_train, decoder_biases_para_train, p, q = nonlinear_autoencoder(
                Normalized_x_para_train, train_dim, current_latent_dim, [current_width_number], activation='relu')
            z_para_test, Normalized_x_para_test_decode, encoder_test_weights_para_test, encoder_test_biases_para_test, decoder_test_weights_para_test, decoder_test_biases_para_test = nonlinear_autoencoder_test(
                Normalized_x_para_test, train_dim, current_latent_dim, [current_width_number], p, q, activation='relu')

            MSE_normalx[i, j] = mean_squared_error(Normalized_x_para_test_decode, Normalized_x_para_test)
            # RMSE_normalx[i, j] = math.sqrt(mean_squared_error(Normalized_x_para_test_decode, Normalized_x_para_test))
            # NDEI_normalx[i, j] = RMSE_normalx[i, j] / st.stdev(Normalized_x_para_test.flatten())
            # MAE_normalx[i, j] = mean_absolute_error(Normalized_x_para_test_decode, Normalized_x_para_test)

            print('current latent_dim = ', current_latent_dim)
            print('current widths = ', current_width_number)

    latent_dim_optwh, widths_optwh = np.where(MSE_normalx == np.min(MSE_normalx))
    # latent_dim_optwh, widths_optwh = np.where(RMSE_normalx == np.min(RMSE_normalx))
    # latent_dim_optwh, widths_optwh = np.where(NDEI_normalx == np.min(NDEI_normalx))
    # latent_dim_optwh, widths_optwh = np.where(MAE_normalx == np.min(MAE_normalx))

    latent_dim_opt = latent_dim_optwh + 1
    widths_opt = widths_optwh + 1

    latent_dim_opt = int(latent_dim_opt)
    widths_opt = int(widths_opt)

    print('optimal latent_dim =', latent_dim_opt)
    print('optimal widths =', widths_opt)
    return latent_dim_opt, widths_opt


#latent_dim_opt, widths_opt = optimal_parameters(Normalized_x_para_train, Normalized_x_para_test)

#########################################
latent_dim_opt = 5  # 8
widths_opt = 10     # 5
#########################################

z_train, X_train_pred, xtrain_encoder_weights, xtrain_encoder_biases, xtrain_decoder_weights, xtrain_decoder_biases, p, q = nonlinear_autoencoder(
    Normalized_x, xtrain_dim, latent_dim_opt, [widths_opt], activation='relu')

print('p=', p)
print('q=', q)

z_test, X_test_pred, xtest_encoder_weights, xtest_encoder_biases, xtest_decoder_weights, xtest_decoder_biases = nonlinear_autoencoder_test(
    Normalized_x_test, xtrain_dim, latent_dim_opt, [widths_opt], p, q, activation='relu')


variable = 5
fig, (ax1, ax2, ax3, ax4) = plt.subplots(4)
fig.suptitle('Prediction & Original Data')
ax1.plot(X_train_pred[3:xtrain_num, variable], color='blue', label='prediction')
ax2.plot(Normalized_x[3:xtrain_num, variable], color='green', label='origin')
ax3.plot(X_test_pred[3:xtest_num, variable], color='blue', label='prediction')
ax4.plot(Normalized_x_test[3:xtest_num, variable], color='green', label='origin')
#plt.plot(X_train_pred[0:xtrain_num,1], color='blue', label='prediction')
#plt.plot(Normalized_x[0:xtrain_num,1], color='green', label='origin')
#plt.plot(X_test_pred[3:xtest_num,3], color='blue', label='prediction')
#plt.plot(Normalized_x_test[3:xtest_num,2], color='green', label='origin')
#plt.plot(X_test_pred[:,1], color='green', label='test')
plt.ylabel('Output')
plt.xlabel('Samples')
plt.title('Prediction')
plt.legend()
plt.show()


print('optimal latent_dim = ', latent_dim_opt)
print('optimal widths = ', widths_opt)
print("xtrain_dim = ", xtrain_dim)
print("xtrain_num = ", xtrain_num)


# ------------------------- Metrics -------------------------
from sklearn.metrics import mean_squared_error
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import r2_score
import statistics as st

MSE_train = mean_squared_error(X_train_pred, Normalized_x)
MSE_test = mean_squared_error(X_test_pred, Normalized_x_test)
print('MSE_train', MSE_train)
print('MSE_test', MSE_test)

RMSE_train = math.sqrt(mean_squared_error(X_train_pred, Normalized_x))
RMSE_test = math.sqrt(mean_squared_error(X_test_pred, Normalized_x_test))
print('RMSE_train', RMSE_train)
print('RMSE_test', RMSE_test)

NDEI_train = RMSE_train / st.stdev(Normalized_x.flatten())
NDEI_test = RMSE_test / st.stdev(Normalized_x_test.flatten())
print('NDEI_train', NDEI_train)
print('NDEI_test', NDEI_test)

MAE_train = mean_absolute_error(X_train_pred, Normalized_x)
MAE_test = mean_absolute_error(X_test_pred, Normalized_x_test)
print('MAE_train', MAE_train)
print('MAE_test', MAE_test)

R2_train = r2_score(X_train_pred, Normalized_x)
R2_test = r2_score(X_test_pred, Normalized_x_test)
print("R2_train = ", R2_train)
print("R2_test = ", R2_test)

end = time.process_time()
process_time = end - start

########
# ------------------------- Anomaly Score -------------------------
def anomaly_score(x_normal, x_normal_pred, x_test, x_test_pred):
    xnormal_num, xnormal_dim = np.shape(x_normal)
    xtest_num, xtest_dim = np.shape(x_test)
    error_normal = np.zeros(shape=(xnormal_num, xnormal_dim))
    error = np.zeros(shape=(xtest_num, xtest_dim))
    threshold = np.zeros(shape=(xnormal_num))
    # std_normal = np.zeros(shape=(xnormal_num))
    ascore = np.zeros(shape=(xtest_num))
    mu_i = np.mean(np.mean(x_normal))
    ascorei_std = np.zeros(shape=(xtest_num))
    anomaly_x = []
    anomaly_y = []

    for i in range(xnormal_num):
        error_normal[i, :] = np.abs(x_normal[i, :] - x_normal_pred[i, :])
        # error_normal[i, :] = np.abs(x_normal[i, :] - x_normal_pred[i, :])
    for i in range(xnormal_num):
        #threshold[i] = (error_normal[i, :] - np.mean(x_normal)).T @ np.cov(x_normal.T) @ (error_normal[i, :] - np.mean(x_normal))
        #threshold[i] = np.mean(error_normal[i, :])
        threshold[i] = (error_normal[i, :] - np.mean(error_normal)).T @ np.cov(error_normal.T) @ (
                    error_normal[i, :] - np.mean(error_normal))

    for i in range(xtest_num):
        error[i, :] = np.abs(x_test[i, :] - x_test_pred[i, :])
    for i in range(xtest_num):
        #ascore[i] = (error[i, :] - np.mean(x_test)).T @ np.cov(x_test.T) @ (error[i, :] - np.mean(x_test))
        #ascore[i] = error[i, :].T @ error[i, :]
        ascore[i] = (error[i, :] - np.mean(error)).T @ np.cov(error.T) @ (error[i, :] - np.mean(error))

    threshold = np.mean(threshold) * np.ones(shape=(xtest_num))
    anomalies = np.where(ascore > threshold)[0]

    faulty_binary = np.zeros(shape=xtest_num)

    for i in range(xtest_num):
        if ascore[i] > threshold[i]:
            anomaly_x = np.append(anomaly_x, [i])
            anomaly_y = np.append(anomaly_y, [ascore[i]])
            faulty_binary[i] = 1               

    return ascore, anomalies, anomaly_x, anomaly_y, faulty_binary


ascore_test_2, anomalies_test, faulty_ae_no, faulty_ae_value, faulty_ae_binary = anomaly_score(Normalized_x, X_train_pred, Normalized_x_test, X_test_pred)
#ascore_test_2, anomalies_test, faulty_ae_no, faulty_ae_value, faulty_ae_binary = anomaly_score(Normalized_x, z_train, Normalized_x_test, z_test)

#tt0_2 = xtrain_num
#tt1_2 = xtest_num
#XX0_2 = np.linspace(1, tt0_2, tt0_2)
#XX1_2 = np.linspace(1, tt1_2, tt1_2)
#threshold_2 = np.mean(np.mean(ascore_test_2))
#plt.plot(ascore_test_2[3:xtest_num], color='blue', label='faulty')
## plt.scatter(anomaly_x_test_2, anomaly_y_test_2, alpha=0.6, c='red', marker='v', label='anomaly')
#plt.plot((threshold_2 * np.ones(shape=tt1_2-3)), color='green', label='threshold')
##plt.plot(threshold, color='green', label='threshold')
#plt.ylabel('Output')
#plt.xlabel('Samples')
#plt.title('DHL-AE')
#plt.legend()
#plt.show()

tt0_2 = xtrain_num
tt1_2 = xtest_num
XX0_2 = np.linspace(1, tt0_2, tt0_2)
XX1_2 = np.linspace(1, tt1_2, tt1_2)
threshold_2 = np.mean(np.mean(ascore_test_2))
plt.plot(ascore_test_2[3:xtest_num], color='blue', label='faulty')
#plt.plot(ascore_test_2, color='blue', label='faulty')
# plt.scatter(anomaly_x_test_2, anomaly_y_test_2, alpha=0.6, c='red', marker='v', label='anomaly')
plt.plot((threshold_2 * np.ones(shape=tt1_2-3)), color='green', label='threshold')
#plt.plot(threshold, color='green', label='threshold')
plt.ylabel('Output')
plt.xlabel('Samples')
plt.title('DHL-AE')
plt.legend()
plt.show()


faulty_ae_no = []
faulty_ae_value = []
faulty_ae_binary = np.zeros(shape=xtest_num)
ascore_ae = ascore_test_2[3:xtest_num]
threshold_2 = np.mean(np.mean(ascore_ae)) 
for i in range(len(ascore_ae)):
    if ascore_ae[i] > threshold_2:
        faulty_ae_no = np.append(faulty_ae_no, [i])
        faulty_ae_value = np.append(faulty_ae_value, [ascore_ae[i]])
        faulty_ae_binary[i] = 1    


###########################################################
# ----------------- Variational Autoencoder (VAE) -----------------
from keras.models import Model
from keras.layers import Dense, Input
import torch
import torch.nn as nn
from tqdm import tqdm
# from torchvision.utils import save_image, make_grid

# Model Hyperparameters
#dataset_path = '~/datasets'
cuda = True
DEVICE = torch.device("cuda" if cuda else "cpu")
batch_size = 100
x_dim = xtrain_dim
hidden_dim = x_dim-10 #5
latent_dim = x_dim-18 #8
lr = 1e-3
epochs = 30

# Step 1. Load (or download) Dataset

# Step 2. Define model: Variational AutoEncoder (VAE)
"""
    A simple implementation of Gaussian MLP Encoder and Decoder
"""
class Encoder(nn.Module):
    def __init__(self, input_dim, hidden_dim, latent_dim):
        super(Encoder, self).__init__()

        self.FC_input = nn.Linear(input_dim, hidden_dim)
        self.FC_input2 = nn.Linear(hidden_dim, hidden_dim)
        self.FC_mean = nn.Linear(hidden_dim, latent_dim)
        self.FC_var = nn.Linear(hidden_dim, latent_dim)

        self.LeakyReLU = nn.LeakyReLU(0.5) #0.5

        self.training = True

    def forward(self, x):
        x = torch.from_numpy(np.asarray(x)).float()
        h_ = self.LeakyReLU(self.FC_input(x))
        h_ = self.LeakyReLU(self.FC_input2(h_))
        mean = self.FC_mean(h_)
        log_var = self.FC_var(h_)  # encoder produces mean and log of variance
        #             (i.e., parateters of simple tractable normal distribution "q"

        return mean, log_var


class Decoder(nn.Module):
    def __init__(self, latent_dim, hidden_dim, output_dim):
        super(Decoder, self).__init__()
        self.FC_hidden = nn.Linear(latent_dim, hidden_dim)
        self.FC_hidden2 = nn.Linear(hidden_dim, hidden_dim)
        self.FC_output = nn.Linear(hidden_dim, output_dim)

        self.LeakyReLU = nn.LeakyReLU(0.5) #0.2

    def forward(self, x):
        h = self.LeakyReLU(self.FC_hidden(x))
        h = self.LeakyReLU(self.FC_hidden2(h))

        x_hat = torch.sigmoid(self.FC_output(h))
        return x_hat


class Model(nn.Module):
    def __init__(self, Encoder, Decoder):
        super(Model, self).__init__()
        self.Encoder = Encoder
        self.Decoder = Decoder

    def reparameterization(self, mean, var):
        epsilon = torch.randn_like(var)  # sampling epsilon
        z = mean + var * epsilon  # reparameterization trick
        return z

    def forward(self, x):
        x = torch.from_numpy(np.asarray(x)).float()
        mean, log_var = self.Encoder(x)
        z = self.reparameterization(mean, torch.exp(0.5 * log_var))  # takes exponential function (log var -> var)
        x_hat = self.Decoder(z)
        return x_hat, mean, log_var


encoder = Encoder(input_dim=x_dim, hidden_dim=hidden_dim, latent_dim=latent_dim)
decoder = Decoder(latent_dim=latent_dim, hidden_dim=hidden_dim, output_dim=x_dim)
#model = Model(Encoder=encoder, Decoder=decoder).to(DEVICE)
model = Model(Encoder=encoder, Decoder=decoder)

# Step 3. Define Loss function (reprod. loss) and optimizer
from torch.optim import Adam
BCE_loss = nn.BCELoss()
def loss_function(x, x_hat, mean, log_var):
    reproduction_loss = nn.functional.binary_cross_entropy(x_hat, x, reduction='sum')
    KLD = - 0.5 * torch.sum(1+ log_var - mean.pow(2) - log_var.exp())
    return reproduction_loss + KLD
optimizer = Adam(model.parameters(), lr=lr)

# Step 4. Train Variational AutoEncoder (VAE)
print("Start training VAE...")
model.train()
model.eval()

#X_train_pred, commitment_loss_train, codebook_loss_train, perplexity_train = model(Normalized_X_train)
#X_test_pred, commitment_loss_test, codebook_loss_test, perplexity_test = model(Normalized_X_test)

X_train_pred_tensor, commitment_loss_train, codebook_loss_train = model(Normalized_x)
X_test_pred_tensor, commitment_loss_test, codebook_loss_test = model(Normalized_x_test)
X_train_pred_vae = X_train_pred_tensor.detach().cpu().numpy()
X_test_pred_vae = X_test_pred_tensor.detach().cpu().numpy()

ascore_test_vae, anomalies_test_vae, faulty_vae_no, faulty_vae_value, faulty_vae_binary = anomaly_score(Normalized_x, X_train_pred_vae, Normalized_x_test, X_test_pred_vae)

faulty_vae_no = []
faulty_vae_value = []
faulty_vae_binary = np.zeros(shape=xtest_num)
ascore_vae = ascore_test_vae
threshold_vae = np.mean(np.mean(ascore_vae)) 
for i in range(len(ascore_vae)):
    if ascore_vae[i] > threshold_vae:
        faulty_vae_no = np.append(faulty_vae_no, [i])
        faulty_vae_value = np.append(faulty_vae_value, [ascore_vae[i]])
        faulty_vae_binary[i] = 1 


tt0_2 = xtrain_num
tt1_2 = xtest_num
XX0_2 = np.linspace(1, tt0_2, tt0_2)
XX1_2 = np.linspace(1, tt1_2, tt1_2)
threshold_vae = np.mean(np.mean(ascore_test_vae))
plt.plot(XX1_2, ascore_test_vae, color='blue', label='faulty')
#plt.scatter(anomaly_x_test_2, anomaly_y_test_2, alpha=0.6, c='red', marker='v', label='anomaly')
plt.plot(XX1_2, (threshold_vae * np.ones(shape=tt1_2)), color='green', label='threshold')
plt.ylabel('Output')
plt.xlabel('Samples')
plt.title('VAE')
plt.legend()
plt.show()


import pandas as pd
#threshold_vae_average = 0.0000103461537159089
#ascore_test_vae_average = pd.read_excel('VAE_ascore_average.xlsx')
#plt.plot(ascore_test_vae_average, color='blue', label='faulty')
#plt.plot((threshold_vae_average * np.ones(shape=xtest_num)), color='green', label='threshold')
#plt.ylabel('Output')
#plt.xlabel('Samples')
#plt.title('VAE')
#plt.legend()
#plt.show()

############################################################
variable = 2  # IDV(2)
# variable = 8 #IDV(6)

#plt.figure()
#plt.subplot(2, 1, 1)
#plt.plot(X_train_pred[:, variable], color='b', label='predictive training data')
#plt.plot(Normalized_x[:, variable], color='r', label='original training data')
#plt.legend(loc='best')
#plt.title('Training data')
#plt.subplot(2, 1, 2)
#plt.plot(X_test_pred[:, variable], color='b', label='predictive testing data')
#plt.plot(Normalized_x_test[:, variable], color='r', label='original testing data')
#plt.legend(loc='best')
#plt.title('Testing data')
#plt.show()

#############################################################
# ------------------------- DKPCA & Anomaly Score -------------------------
# from sklearn.decomposition import PCA
#import matlab
#import matlab.engine


# eng = matlab.engine.start_matlab()


def kernel_function(X1, sig_k):
    num = X1.shape[0]
    K = np.zeros((num, num))

    for a in range(num):
        K[a, a] = 0
        for b in range(a + 1, num):
            xa = X1[a, :]
            xb = X1[b, :]
            K[a, b] = np.linalg.norm(xa - xb) ** 2
            K[b, a] = K[a, b]

    K0 = (1 / sig_k) * K
    #print('K0 shape:', np.shape(K0))
    M = np.eye(num) - np.ones((num, num)) / num
    #print('M shape:', np.shape(M))
    K1 = np.dot(np.dot(M, K0), M)
    #print('K1 shape:', np.shape(K1))
    return K1


sig = 500
#sig = 30000
K_train = kernel_function(Normalized_x, sig)
#print('K_train shape:', np.shape(K_train))
K_test = kernel_function(Normalized_x_test, sig)
#print('K_test shape:', np.shape(K_test))

s = 20
#s = 5


#########

def dipca(X0, a, s):
    n, m = X0.shape
    N = n - s

    T = np.zeros((n, a))
    W = np.zeros((m, a))
    P = np.zeros((m, a))
    Alpha = np.zeros((s, a))
    Beta = np.zeros((s, a))
    Vd = np.zeros((N, a))
    VV = np.zeros((N, a))

    for l in range(a):
        # S1: initialize w to a random unit vector
        w = np.random.randn(m)
        w /= np.linalg.norm(w)

        # S2: iterate until convergence
        J_prev = 1000
        iteration_count = 1
        max_iterations = 1000  # Set your maximum iteration limit here
        while iteration_count <= max_iterations:
            t = X0.dot(w)

            # form Ts
            Ts = np.zeros((N, s + 1))
            for i in range(1, s + 2):
                Ts[:, i - 1] = t[i - 1:N + i - 1]

            beta = Ts[:, :s].T.dot(Ts[:, s])
            beta /= np.linalg.norm(beta)

            w = np.zeros(m)
            J = 0
            for i in range(1, s):
                w += beta[i] * (X0[s:N + s, :].T.dot(Ts[:, i]) + X0[i:i + N, :].T.dot(Ts[:, s]))
                J += beta[i] * Ts[:, i].T.dot(Ts[:, s])
            w /= np.linalg.norm(w)

            if abs(J - J_prev) < 0.0001:
                break
            J_prev = J
            iteration_count += 1

        if iteration_count > max_iterations:
            print('for {}: iteration exceeded {} iterations'.format(l, max_iterations))
            break

        # S3: inner modeling
        alpha = np.linalg.inv(Ts[:, :s].T.dot(Ts[:, :s])).dot(Ts[:, :s].T).dot(Ts[:, s])
        vd = Ts[:, s] - Ts[:, :s].dot(alpha)
        vv = Ts[:, :s].dot(alpha)

        # S4: deflation
        t_normalized = t / (t.T.dot(t))
        p = X0.T.dot(t_normalized)
        X0 -= np.outer(t, p)

        T[:, l] = t
        P[:, l] = p
        W[:, l] = w
        Alpha[:, l] = alpha
        Beta[:, l] = beta
        Vd[:, l] = vd
        VV[:, l] = vv

    # R = W.dot(np.linalg.pinv(P.T.dot(W)))

    return T, P


#########

def pc_determine(x, a):
    x_num, x_dim = np.shape(x)
    mse = np.zeros(shape=x_dim)
    # x_train = x[0:int(x_num / 4 * 3), :]
    # x_test = x[int(x_num / 4 * 3) + 1: x_num - 1, :]
    for i in range(1, a):
        # results_i = eng.dipca(x, i, s)
        # print('x', x)
        T_i, P_i = dipca(x, i, s)
        x_pred = np.matmul(T_i, P_i.T)
        #print('T_i shape:', np.shape(T_i))
        #print('P_i shape:', np.shape(P_i))
        #print('x shape:', np.shape(x))

        # print('x_pred', x_pred)
        # x_test_pred = np.matmul(x_test_transformed, pcs_i) + x_train.mean()
        mse[i] = mean_squared_error(x_pred, x)

    pc_num = np.argmin(np.array(mse))
    pc_num = pc_num + 1
    print('The number of principal components:', pc_num)
    return pc_num


pc_num = pc_determine(K_train, xtrain_dim)
pc_num = 15
#print('pc_num:', pc_num)
T_train, P_train = dipca(K_train, pc_num, s)
K_test = kernel_function(Normalized_x_test, sig)
T_test, P_test = dipca(K_test, pc_num, s)

K_train_pred_pca = np.matmul(T_train, P_train.T)
#print('K_train_pred_pca shape:', np.shape(K_train_pred_pca))
K_test_pred_pca = np.matmul(T_test, P_test.T)
#print('K_test_pred_pca shape:', np.shape(K_test_pred_pca))


#############################################################
def anomaly_score_pca(x_normal, x_normal_pred, x_test, x_test_pred):
    xnormal_num, xnormal_dim = np.shape(x_normal)
    xtest_num, xtest_dim = np.shape(x_test)
    error_normal = np.zeros(shape=(xnormal_num, xnormal_dim))
    error = np.zeros(shape=(xtest_num, xtest_dim))
    threshold = np.zeros(shape=(xnormal_num))
    # std_normal = np.zeros(shape=(xnormal_num))
    ascore = np.zeros(shape=(xtest_num))
    mu_i = np.mean(np.mean(x_normal))
    ascorei_std = np.zeros(shape=(xtest_num))
    anomaly_x = []
    anomaly_y = []

    #for i in range(xnormal_num):
    #    error_normal[i, :] = np.abs(x_normal_pred[i, :] - x_normal[i, :])
    #    #error_normal[i, :] = np.abs(x_normal[i, :] - x_normal_pred[i, :])
    #    #threshold[i] = (error_normal[i, :] - np.mean(x_normal)).T @ np.cov(x_normal.T) @ (error_normal[i, :] - np.mean(x_normal))
    #    threshold[i] = -np.mean(error_normal[i, :]) - 0.75 * 0.00000001 + 3 * 0.00000001

    #for i in range(xtest_num):
    #    error[i, :] = np.abs(x_test_pred[i, :] - x_test[i, :])
    #    #ascore[i] = (error[i, :] - np.mean(x_test)).T @ np.cov(x_test.T) @ (error[i, :] - np.mean(x_test))
    #    ascore[i] = -np.mean(error[i, :]) + 3 * 0.00000001

    ########
    for i in range(xnormal_num):
        error_normal[i, :] = np.abs(x_normal_pred[i, :] - x_normal[i, :])
        #threshold[i] = -np.mean(error_normal[i, :]) + 1.42 * 0.000000000001
        threshold[i] = np.mean(error_normal[i, :])

    for i in range(xtest_num):
        error[i, :] = np.abs(x_test_pred[i, :] - x_test[i, :])
        #ascore[i] = (error[i, :] - np.mean(x_test)).T @ np.cov(x_test.T) @ (error[i, :] - np.mean(x_test))
        #ascore[i] = np.mean(error[i, :])
        #ascore[i] = error[i, :].T @ error[i, :]
        #ascore[i] = -error[i, :].T @ error[i, :] + 0.1 * 0.000000000001 + 1.4 * 0.000000000001
        ascore[i] = -error[i, :].T @ error[i, :]

    #################

    #std_normal = np.std(ascore)
    #interval = 20
    #for i in range(xtest_num):
        #if (i > interval) & (i < xtest_num - interval):
            #ascorei_std[i] = np.std(ascore[i - interval: i + interval])
            #if ascorei_std[i] > std_normal:
                #anomaly_x = np.append(anomaly_x, [i])
                #anomaly_y = np.append(anomaly_y, [ascore[i]])
    
    threshold = np.mean(threshold) * np.ones(shape=(xtest_num))
    anomalies = np.where(ascore > threshold)[0]

    faulty_binary = np.zeros(shape=xtest_num)

    for i in range(xtest_num):
        if ascore[i] > threshold[i]:
            anomaly_x = np.append(anomaly_x, [i])
            anomaly_y = np.append(anomaly_y, [ascore[i]])
            faulty_binary[i] = 1           
    
    plt.plot(threshold, color='green', label='threshold')
    plt.plot(ascore, color='blue', label='faulty')
    plt.ylabel('Output')
    plt.xlabel('Samples')    
    plt.title('DKPCA')
    plt.legend()
    plt.show()
    
    return ascore, anomalies, anomaly_x, anomaly_y, faulty_binary


#ascore_train_pca, anomalies_train_pca, faulty_pca_no_train, faulty_pca_value_train, faulty_pca_binary_train = anomaly_score_pca(K_train, K_train_pred_pca, K_train, K_train_pred_pca)
ascore_test_pca, anomalies_test_pca, faulty_pca_no, faulty_pca_value, faulty_pca_binary = anomaly_score_pca(K_train, K_train_pred_pca, K_test, K_test_pred_pca)


#############################################################

faulty_test_binary = np.zeros(shape=(xtest_num))
ascore_data, anomalies_data, faulty_data_no, faulty_data_value, faulty_test_binary = anomaly_score(Normalized_x, X_train_pred, Normalized_x_test, Normalized_x_test)

threshold_data = np.mean(Normalized_x_test) * np.ones(shape=(xtest_num))
Normalized_x_test_mean = np.mean(Normalized_x_test, axis=1)

for i in range(xtest_num):
    if Normalized_x_test_mean[i] > threshold_data[i]:
        faulty_test_binary[i] = 1
        
plt.plot(threshold_data, color='red', label='threshold')
#plt.plot(ascore_data, color='green', label='faulty')
plt.plot(Normalized_x_test_mean, color='blue', label='data')
plt.ylabel('Output')
plt.xlabel('Samples')    
plt.title('Test Data')
plt.legend()
plt.show()


#############################################################
from sklearn.metrics import accuracy_score, precision_score, recall_score

accuracy_score_ae = accuracy_score(faulty_test_binary, faulty_ae_binary)
precision_score_ae = precision_score(faulty_test_binary, faulty_ae_binary)
recall_score_ae = recall_score(faulty_test_binary, faulty_ae_binary)
F1_score_ae = 2 * (precision_score_ae * recall_score_ae) / (precision_score_ae + recall_score_ae)

accuracy_score_dkpca = accuracy_score(faulty_test_binary, faulty_pca_binary)
precision_score_dkpca = precision_score(faulty_test_binary, faulty_pca_binary)
recall_score_dkpca = recall_score(faulty_test_binary, faulty_pca_binary)
F1_score_dkpca = 2 * (precision_score_dkpca * recall_score_dkpca) / (precision_score_dkpca + recall_score_dkpca)

accuracy_score_vae = accuracy_score(faulty_test_binary, faulty_vae_binary)
precision_score_vae = precision_score(faulty_test_binary, faulty_vae_binary)
recall_score_vae = recall_score(faulty_test_binary, faulty_vae_binary)
F1_score_vae = 2 * (precision_score_vae * recall_score_vae) / (precision_score_vae + recall_score_vae)


print('accuracy_score_ae =', accuracy_score_ae)
print('precision_score_ae =', precision_score_ae)
print('recall_score_ae =', recall_score_ae)
print('F1_score_ae =', F1_score_ae)

print('accuracy_score_vae =', accuracy_score_vae)
print('precision_score_vae =', precision_score_vae)
print('recall_score_vae =', recall_score_vae)
print('F1_score_vae =', F1_score_vae)

print('accuracy_score_dkpca =', accuracy_score_dkpca)
print('precision_score_dkpca =', precision_score_dkpca)
print('recall_score_dkpca =', recall_score_dkpca)
print('F1_score_dkpca =', F1_score_dkpca)

# ------------------------- Confusion Matrix -------------------------
# from pycm import *
from sklearn.metrics import confusion_matrix

cm_ae = confusion_matrix(faulty_test_binary, faulty_ae_binary)
print('cm_ae: ', cm_ae)

TP_ae = cm_ae[0, 0]
FN_ae = cm_ae[0, 1]
FP_ae = cm_ae[1, 0]
TN_ae = cm_ae[1, 1]
FDR_ae = TP_ae / (TP_ae + FN_ae)
FAR_ae = FP_ae / (TN_ae + FP_ae)
MAR_ae = FN_ae / (TP_ae + FN_ae)
print('FDR_ae = ', FDR_ae)
print('FAR_ae = ', FAR_ae)
print('MAR_ae = ', MAR_ae)

cm_vae = confusion_matrix(faulty_test_binary, faulty_vae_binary)
print('cm_vae: ', cm_vae)

TP_vae = cm_vae[0, 0]
FN_vae = cm_vae[0, 1]
FP_vae = cm_vae[1, 0]
TN_vae = cm_vae[1, 1]
FDR_vae = TP_vae / (TP_vae + FN_vae)
FAR_vae = FP_vae / (TN_vae + FP_vae)
MAR_vae = FN_vae / (TP_vae + FN_vae)
print('FDR_vae = ', FDR_vae)
print('FAR_vae = ', FAR_vae)
print('MAR_vae = ', MAR_vae)

cm_dkpca = confusion_matrix(faulty_test_binary, faulty_pca_binary)
print('cm_dkpca: ', cm_dkpca)

TP_dkpca = cm_dkpca[0, 0]
FN_dkpca = cm_dkpca[0, 1]
FP_dkpca = cm_dkpca[1, 0]
TN_dkpca = cm_dkpca[1, 1]
FDR_dkpca = TP_dkpca / (TP_dkpca + FN_dkpca)
FAR_dkpca = FP_dkpca / (TN_dkpca + FP_dkpca)
MAR_dkpca = FN_ae / (TP_dkpca + FN_dkpca)
print('FDR_dkpca = ', FDR_dkpca)
print('FAR_dkpca = ', FAR_dkpca)
print('MAR_dkpca = ', MAR_dkpca)