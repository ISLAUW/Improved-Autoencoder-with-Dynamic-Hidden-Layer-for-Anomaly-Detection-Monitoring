%function [P, R, Alpha, VV, P_vd, lambda_vd, T2_lim_vd, Q_lim_vd] = dipca(X0,a,s)
function [P, R, Alpha, VV, P_vd, lambda_vd] = dipca(X0,a,s)
%X_back = X0;

[n, m] = size(X0);
N = n - s;

T = zeros(n, a);
W = zeros(m, a);
P = zeros(m, a);
Alpha = zeros(s, a);
Beta = zeros(s, a);
Vd = zeros(N, a);
VV = zeros(N, a);

for l = 1:a
    % S1: initialize w to a random unit vector;
    w = randn(m, 1);
    w = w / norm(w);
    
    % S2: iterate until convergence
    J_prev = 10000;
    iter = 1;
    while true
        t = X0*w;
        
        % form Ts
        Ts = zeros(N, s+1);
        for i = 1:s+1
            Ts(:, i) = t(i:N+i-1);
        end
        beta = Ts(:, 1:s)'*Ts(:, s+1);
        beta = beta / norm(beta);
        
        w = zeros(m, 1);
        J = 0;
        for i = 1:s
            w = w + beta(i)*(X0(s+1:s+N, :)'*Ts(:, i) + X0(i:i+N-1, :)'*Ts(:, s+1));
            J = J + beta(i)*Ts(:, i)'*Ts(:, s+1);
        end
        w = w / norm(w);
        
        if abs(J - J_prev) < 0.0001
            break;
        end
        J_prev = J;
        iter = iter + 1;
        
        if iter > 10000
           fprintf('for %d: iteration exceed 1000\n', l);
           break;
        end
    end
    % S3: inner modeling
    alpha = (Ts(:, 1:s)'*Ts(:, 1:s))^(-1)*Ts(:, 1:s)'*Ts(:, s+1);
    vd = Ts(:, s+1) - Ts(:, 1:s)*alpha;
    vv = Ts(:, 1:s)*alpha;
    
    % S4: deflation
    p = X0'*t/(t'*t);
    X0 = X0 - t*p';
    
    T(:, l) = t;
    P(:, l) = p;
    W(:, l) = w;
    Alpha(:, l) = alpha;
    Beta(:, l) = beta;
    Vd(:, l) = vd;
    VV(:,l) = vv;
end

R = W*pinv(P'*W);


%% Monitoring
% performing PCA on Vd
% a_vd = pc_number(Vd);
% [P_vd, lambda_vd, T2_lim_vd, Q_lim_vd] = PCA(Vd, a_vd);

%a_vd = pc_number(VV'*VV);
%[P_vd, lambda_vd, T2_lim_vd, Q_lim_vd] = PCA(VV, a_vd);





