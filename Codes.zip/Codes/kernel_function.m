%% ————Kernel Function————
function K1 = kernel_function(X1,sig_k)
num=size(X1,1); 
K(:,:)=zeros(num);
for a=1:num
    K(a,a)=0;
    for b=a+1:num
        xa=X1(a,:); xb=X1(b,:);
        K(a,b)=(norm(xa-xb))^2;
        K(b,a)=K(a,b);           
    end
end
K0(:,:)=zeros(num);
for a=1:num
    for b=1:num
        K0(a,b)=(1/sig_k)*K(a,b);
    end
end
M=eye(num)-ones(num,num)/num;
K1=M*K0*M; 
end